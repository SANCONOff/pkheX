# PKHeX.Discord
PKHeX API Discord Bot (WIP)

Leverages PKHeX related logic in Discord servers that the bot is present in.

Supported bots: Axew
- See the Commands folder for the supported commands (.help)
- Automatic Legality (via ShowdownSet paste, or attached PKM file)
- Legality checking (via attached PKM file)
- Index/PersonalInfo fetch
- Move Learnability

Check it out in the [Auto Legality Mod](https://github.com/architdate/PKHeX-Plugins) Discord (see link readme for invite).
